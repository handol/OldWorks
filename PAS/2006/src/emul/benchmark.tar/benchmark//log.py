#!/usr/local/bin/python

DEBUG_LEVEL = 0

def getLogLevel():
    global DEBUG_LEVEL
    return DEBUG_LEVEL

def setLogLevel(level):
    global DEBUG_LEVEL
    DEBUG_LEVEL = level







