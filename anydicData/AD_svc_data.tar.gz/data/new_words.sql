insert into word_list values ('I', 0, 0, 0, 3, 0x03, 0,0,0, Null, 0, 0);
insert into word_list values ('those', 0, 0, 0, 3, 0x07, 0,0,0, Null, 0, 0);
insert into word_list values ("won't", 0, 0, 0, 3, 0x0400, 0,0,0, "would", 0, 0);
insert into word_list values ("cyber", 0, 0, 0, 2, 0x05, 0,0,0, Null, 0, 0);
insert into word_list values ("online", 0, 0, 0, 2, 0x05, 0,0,0, Null, 0, 0);
insert into word_list values ('etc', 0, 0, 0, 2, 0x01, 0,0,0, Null, 0, 0);
insert into word_list values ('vs', 0, 0, 0, 2, 0x01, 0,0,0, Null, 0, 0);
insert into word_list values ('cannot', 0, 0, 0, 3, 0x400, 0,0,0, 'can', 0, 0);
insert into word_list values ('transformative', 0, 0, 0, 0, 0x04, 0,1,0, 'transform', 0, 0);
insert into word_list values ('An', 0, 0, 0, 3, 0x100, 0,0,0, Null, 0, 0);
insert into word_list values ('The', 0, 0, 0, 3, 0x100, 0,0,0, Null, 0, 0);
insert into word_list values ('August', 0, 0, 0, 3, 0x1, 0,0,0, Null, 0, 0);

insert into word_list values ('op', 0, 0, 0, 0, 0x1, 0,1,0, 'operation', 0, 0);
insert into word_list values ('celeb', 0, 0, 0, 0, 0x1, 0,1,0, 'celebrity', 0, 0);

insert into word_list values ('sports', 0, 0, 0, 2, 0x1, 0,0,0, 'sport', 0, 0);
